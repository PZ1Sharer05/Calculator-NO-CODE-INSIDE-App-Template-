//
//  ViewController.swift
//  Calculator Design Samsung
//  Design the code here
//  Created by Jeff Sharer on 08/12/18.
//  Copyright © 2018 Sharer05. All rights reserved.
//
//Put your code here
import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

